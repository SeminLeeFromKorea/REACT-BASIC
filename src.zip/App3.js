import { Fragment } from "react";
import StateComponent from "./component/StateComponent"
import StateComponentQ from "./component/StateComponentQ";

const App3 = () => {
    return (
        <>
        <StateComponent />
        <StateComponentQ />
        </>
    )
}

export default App3;