const MyComponent2 = () => {
    return (
        <div>내가 누구? 체육학사 이세민</div>
    )
}

export default MyComponent2;