import { useState } from "react";

/* React에서는 Element를 쓰지 않도록 */
const EventComponentQ2 = () => {

    /*
    const[data, setData] = useState(''); //인풋데이터
    const[reset, setReset] = useState(''); //결과데이터

    const handleData = (e) => {
        setData(e.target.value); //내부적으로 비동기적으로 변경
        console.log(data); //이전값이 출력됩니다(정상)
    }

    const handleReset = () => {
        setReset(data); //사용자가 입력한 값으로 변경
        setData(''); //인풋데이터는 공백으로 변경
    }
    */

    // state를 객체로 관리
    const [form, setForm] = useState({data : '', result: ''}); // 인풋데이터

    const handleChange = (e) => {
        // data는 사용자의 입력값으로, result는 유지
        setForm({data : e.target.value, result : form.result});
    }

    const handleClick = () => {
        // data는 '', result는 data로 변경
        setForm({data : '', result: form.data});
    }

    return (
        <>
        <hr/>
        <h3>인풋데이터 핸들링(실습)</h3>
        <div>클릭시 데이터는 공백으로 결과는 인풋이 입력한 값으로 처리</div>
        <div>힌트는? 아마도 state는 두개가 필요할 듯?</div>
        <input type="text" /* onChange={handleData} */ /* value={data} */ onChange={handleChange} value={form.data}/>
        <button /* onClick={handleReset} */ onClick={handleClick}>추가하기</button>
        <h3>결과</h3>
        <div>{/* {reset} */} {form.result}</div>
        </>
    )
}

export default EventComponentQ2;